/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 *
 * @author NisargPatel
 */
@WebServlet(urlPatterns = {"/New_stud"})
public class New_stud extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
          
            out.println("</html>");
            
            
            
           int id=Integer.parseInt(request.getParameter("id"));
          String fname=request.getParameter("fname");
          String lname=request.getParameter("lname");
          String mob_no=request.getParameter("mob_no");
          String email=request.getParameter("email");
          String branch=request.getParameter("branch");
          String clg=request.getParameter("clg");
          String dob=request.getParameter("dob");
          String city=request.getParameter("city");
          String add=request.getParameter("add"); 
          String pwd=request.getParameter("pwd"); 
          
          
          
          try{
                         Class.forName("com.mysql.jdbc.Driver");
                         String q1="insert into stud_info(stud_id,stud_fname,stud_lname,stud_mob_no,stud_clg,stud_branch,stud_email,stud_dob,stud_city,stud_add,join_date,expaird_date,pwd) values("+id+",'"+fname+"','"+lname+"','"+mob_no+"','"+clg+"','"+branch+"','"+email+"','"+dob+"','"+city+"','"+add+"',sysdate(),date_add(sysdate(),INTERVAL 1 year),'"+pwd+"')";
                          Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library_man_sys?zeroDateTimeBehavior=convertToNull","root","");
           
                        Statement st = con.createStatement();
                         int i=st.executeUpdate(q1);
                          out.println("Registration Succesful....");
                    }catch(Exception e){out.print(e);}
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
